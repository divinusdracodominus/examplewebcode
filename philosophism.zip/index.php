<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/main.css"/>
<title>Philosophism</title>
		<link rel="shortcut icon" href="images/sun.ico" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="js/main.js"></script>
		<script src="js/elements.js"></script>
</head>
<body onload="changeimage()">
<div id="stuff">
		<div id="header">
			<script>
				create_header("header");
			</script>
		</div>
		<div id="mobileheader">
			<center>
			<div id="menubutton">
			<input type="button" id="m_button" value=" ">
			<form action="/proccess.php" method="post">	
						<input type="text" id="mobilesearchfield" placeholder="search" name="term"/>
						<input type="submit" class="search" value=" ">
			</form>
		</div>
			<div id="mobilemenu">
				<h3 class="span" id="h-1">Home</h4>
					<a class="navigation" id="page1" href="/index.html">Home</a>
					<a class="navigation" id="page1-1" href="structure">structure</a>
				
				<h3 class="span" id="h-2">Community</h4>
					<a class="navigation" id="page2" href="/clubs">Clubs</a>
					<a class="navigation" id="page2-1" href="/union">Unions</a>
				
				<h3 class="span" id="h-3">Projects</h4>
					<a href="/arkproject" class="navigation" id="page3">Ark Project</a>
<a href="/education">Encourageing Education</a>
				<h3 class="span" id="h-4">Dashboard</h4>
					<a href="loggedin.php" class="navigation" id="page4-2">My Account</a>
					<a href="/login" class="navigation" id="page4">Login</a>
					<a href="/createaccount" class="navigation" id="page4-1">create account</a>
			</div>
		<center>
</div>
<div id="content">
<div id="leftdiv">
<!--<div id="leftadd">
<center>
<div class="addbar"><h3 class="addtitle" id="lat">some add</h3><input type="button" class="addgone" value="X" id="lca"/></div>
<iframe class="iframe" src="/profileimages/1.png" scrolling="no" id="laif"></iframe>
<p class="p" class="lac">
this would be an add
</p>-->
</center>
</div></div>
<div id="middlediv">
<h1 id="space"></h1>
<h1 class="h1">What is Philosophism?</h1>
<div id="content_background">
<p class="p">philosopism is really similar to how it sounds in that it encourages a love of understanding and knowlege not only of the world around us but also of eachother inorder for us as a society to build a more perfect world. Fundementaly the beleif of Philosophism is that we as a people deserve the right to have a fair just, and well suited education system that encourages many diffrent types of learning. Though one of the main goals of Pilosophism as a philosophical theory is to promote education it also has the goal of promoting scientific understanding and political, societal and social commnication so that moveing into the future we can establish common ground, and decide the best ways to utilize technologies that will forever shape the course of history, such as: the development of AI, and the advances in human gnome research.</p>
<h1 class="h1">Why is it important to persue knowledge?</h1>
<p class="p">The United States is a country built on ideals, it is built on ideals not because it has changed but because it was born out of a new enlightened world. The ideas in the declaration of independence and the constitution lay out a desire for equality and self governance build on greek societies such as ancient Athens.The founding father wished to build a country of equal representation and a protection from arbitrary decisions, and tyranny. Such tyranny's included that: “He (king james) has obstructed the Administration of justice by refusing his assent to Laws for establishing judiciary powers”, or that: “He has erected a multitude of New offices, and sent hither swarms of officers to harass our people, and eat out their substance”.
</p>
<p class="p">The United States is a country built on ideals, it is built on ideals not because it has changed but because it was born out of a new enlightened world. The ideas in the declaration of independence and the constitution lay out a desire for equality and self governance build on greek societies such as ancient Athens.The founding father wished to build a country of equal representation and a protection from arbitrary decisions, and tyranny. Such tyranny's included that: “He (king james) has obstructed the Administration of justice by refusing his assent to Laws for establishing judiciary powers”, or that: “He has erected a multitude of New offices, and sent hither swarms of officers to harass our people, and eat out their substance”.
</p>
</div>
</div>
<div id="rightdiv">
<!--<div id="rightadd">
<center>
<div class="addbar"><h3 class="addtitle" id="rat">some add</h3><input type="button" class="addgone" value="X" id="rca"/></div>
<iframe class="iframe" src="/profileimages/1.png" scrolling="no" id="raif"></iframe>
<p class="p" class="rac">
this would be an add
</p>-->
</center>
</div>
</div>
</div>
</div>
	</body>
</html>
